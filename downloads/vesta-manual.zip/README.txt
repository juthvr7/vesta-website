Vesta HTML manual / 离线用户手册
Extract the entire ZIP, then open index.html in a modern browser.
请完整解压，再用现代浏览器打开 index.html。无需启动服务器。
Chapters, full-text search, hyperlinks, images and the included presentation film work locally.
内容包含章节、全文搜索、超链接、图片和已有展示短片。请保留文件夹结构。
This is a dated documentation snapshot. Evidence dates and scope remain separate from packaging.
这是文档快照；打包日期不改变原验证日期与范围。PDF不是本包的主要阅读形式。
